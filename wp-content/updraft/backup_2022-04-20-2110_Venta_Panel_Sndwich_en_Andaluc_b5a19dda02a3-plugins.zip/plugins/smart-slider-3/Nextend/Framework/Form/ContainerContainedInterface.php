<?php


namespace Nextend\Framework\Form;


interface ContainerContainedInterface extends ContainerInterface, ContainedInterface {

}