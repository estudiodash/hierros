<?php


namespace Nextend\Framework\Visual;


use Nextend\Framework\View\AbstractBlock;

abstract class AbstractBlockVisual extends AbstractBlock {

}