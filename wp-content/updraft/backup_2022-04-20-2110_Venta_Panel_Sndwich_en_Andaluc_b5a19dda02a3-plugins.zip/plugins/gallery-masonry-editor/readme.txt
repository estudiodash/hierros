=== Gallery in columns ===
Contributors: picfab
Tags: gutenberg, gallery, masonry, galerie, images, pictures, picture, image, image
Requires at least: 5.4
Tested up to: 5.4
Requires PHP: 5.6.20
Stable tag: 1.0
License: GPLv3

Fix css which transforms the WordPress\'s gallery without cropped option into beautiful gallery in column

== Description ==
https://youtu.be/yAQtxebfCmY

Transforms the WordPress's gallery into a beautiful gallery in columns.
When you create a gallery do not check the box "Crop images".
This is only a css overload.

== Installation ==
1. Extract the plugin folder from the downloaded ZIP file.
2. Upload the `gallery-masonry-editor` folder to your *wp-content/plugins/* directory.
3. Activate the plugin from the "Plugins" page.
4. Think to disable "Crop images" option in the editor.

== Frequently Asked Questions ==
None, yet.

== Changelog ==
= 1.0 =
* 2020/15/04 - First public release
* 2020/26/04 - Correction in the plugin URI
